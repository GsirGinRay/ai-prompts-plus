/**
 * Content Script - 注入到 ChatGPT 頁面
 * 負責在頁面中插入提示詞和顯示快速訪問按鈕
 */

/**
 * 監聽來自 popup 的訊息
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'insertPrompt') {
    insertPromptToTextarea(request.content);
    sendResponse({ success: true });
  }
  return true;
});

/**
 * 插入提示詞到 ChatGPT 輸入框
 */
function insertPromptToTextarea(content) {
  // ChatGPT 的輸入框選擇器（可能需要根據頁面更新調整）
  const selectors = [
    'textarea[data-id="root"]', // 新版 ChatGPT
    '#prompt-textarea',
    'textarea[placeholder*="Message"]',
    'textarea[placeholder*="Send a message"]',
    'textarea',
  ];

  let textarea = null;

  // 嘗試找到輸入框
  for (const selector of selectors) {
    textarea = document.querySelector(selector);
    if (textarea) break;
  }

  if (!textarea) {
    console.error('找不到 ChatGPT 輸入框');
    showNotification('找不到輸入框，請確認您在 ChatGPT 對話頁面', 'error');
    return;
  }

  // 設置值
  setNativeValue(textarea, content);

  // 觸發輸入事件以確保 React 偵測到變化
  textarea.dispatchEvent(new Event('input', { bubbles: true }));
  textarea.dispatchEvent(new Event('change', { bubbles: true }));

  // 聚焦到輸入框
  textarea.focus();

  // 顯示成功通知
  showNotification('提示詞已插入', 'success');
}

/**
 * 設置原生值（用於 React 控制的輸入框）
 */
function setNativeValue(element, value) {
  const valueSetter = Object.getOwnPropertyDescriptor(element, 'value')?.set ||
    Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), 'value')?.set;

  if (valueSetter) {
    valueSetter.call(element, value);
  } else {
    element.value = value;
  }
}

/**
 * 顯示通知
 */
function showNotification(message, type = 'success') {
  // 移除現有通知
  const existing = document.getElementById('prompt-manager-notification');
  if (existing) existing.remove();

  // 建立通知元素
  const notification = document.createElement('div');
  notification.id = 'prompt-manager-notification';
  notification.className = `prompt-notification ${type}`;
  notification.textContent = message;

  document.body.appendChild(notification);

  // 3 秒後自動移除
  setTimeout(() => {
    notification.classList.add('fade-out');
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

/**
 * 建立快速訪問按鈕
 */
function createQuickAccessButton() {
  // 檢查是否已存在按鈕
  if (document.getElementById('prompt-manager-quick-btn')) return;

  const button = document.createElement('button');
  button.id = 'prompt-manager-quick-btn';
  button.className = 'prompt-quick-btn';
  button.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
  `;
  button.title = '開啟提示詞管理器';

  button.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'openPopup' });
  });

  document.body.appendChild(button);
}

/**
 * 初始化
 */
function init() {
  // 等待頁面載入完成
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createQuickAccessButton);
  } else {
    createQuickAccessButton();
  }
}

// 執行初始化
init();

// 監聽頁面變化（SPA 導航）
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    createQuickAccessButton();
  }
}).observe(document.body, { subtree: true, childList: true });
