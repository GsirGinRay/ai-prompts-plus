# 專案摘要 - ChatGPT 提示詞管理工具

## 📁 專案結構

```
提示詞外掛-chrome extention-prompt plugin/
│
├── manifest.json              # Chrome 擴充功能配置檔案 (Manifest V3)
│
├── 📱 使用者介面
│   ├── popup.html            # 彈出視窗 HTML 結構
│   ├── popup.css             # 彈出視窗樣式（響應式設計）
│   └── popup.js              # 彈出視窗互動邏輯
│
├── 🔧 核心功能
│   ├── storage.js            # 資料儲存管理模組
│   ├── background.js         # 背景服務 Worker
│   ├── content.js            # ChatGPT 頁面注入腳本
│   └── content.css           # ChatGPT 頁面注入樣式
│
├── 🎨 資源
│   └── icons/                # 擴充功能圖示
│       ├── icon16.png        # 16x16 工具列圖示
│       ├── icon48.png        # 48x48 管理頁面圖示
│       ├── icon128.png       # 128x128 商店圖示
│       └── README.md         # 圖示建立指南
│
└── 📚 文件
    ├── README.md             # 完整使用說明
    ├── INSTALLATION.md       # 詳細安裝指南
    └── PROJECT_SUMMARY.md    # 專案摘要（本檔案）
```

## 🎯 核心功能模組

### 1️⃣ 資料儲存模組 (storage.js)

**功能：**
- ✅ 提示詞 CRUD 操作（新增、讀取、更新、刪除）
- ✅ 搜尋和篩選提示詞
- ✅ 匯入/匯出 JSON 格式
- ✅ 變數提取和替換
- ✅ 使用次數統計

**主要方法：**
```javascript
StorageManager.getAllPrompts()           // 取得所有提示詞
StorageManager.savePrompt(prompt)        // 儲存提示詞
StorageManager.deletePrompt(id)          // 刪除提示詞
StorageManager.searchPrompts(query)      // 搜尋提示詞
StorageManager.extractVariables(content) // 提取變數
StorageManager.replaceVariables(content, values) // 替換變數
StorageManager.exportPrompts()           // 匯出
StorageManager.importPrompts(jsonData)   // 匯入
```

### 2️⃣ 彈出視窗模組 (popup.html/css/js)

**功能：**
- ✅ 提示詞列表顯示（卡片式設計）
- ✅ 即時搜尋功能
- ✅ 新增/編輯/刪除提示詞
- ✅ 變數快速插入按鈕
- ✅ 變數輸入模態框
- ✅ 匯入/匯出功能

**介面元件：**
- 搜尋列
- 提示詞卡片列表
- 編輯模態框
- 變數輸入模態框
- 空狀態顯示

### 3️⃣ 內容注入模組 (content.js/css)

**功能：**
- ✅ 監聽訊息並插入提示詞
- ✅ 智慧偵測 ChatGPT 輸入框
- ✅ 處理 React 控制的輸入框
- ✅ 浮動快速訪問按鈕
- ✅ 操作通知顯示

**選擇器陣列：**
```javascript
const selectors = [
  'textarea[data-id="root"]',
  '#prompt-textarea',
  'textarea[placeholder*="Message"]',
  'textarea[placeholder*="Send a message"]',
  'textarea'
];
```

### 4️⃣ 背景服務模組 (background.js)

**功能：**
- ✅ 擴充功能安裝初始化
- ✅ 建立預設範例提示詞
- ✅ 訊息轉發
- ✅ 快捷鍵監聽（未來功能）

## 💾 資料結構

### 提示詞物件結構

```javascript
{
  id: "prompt_1234567890_abc123",    // 唯一識別碼
  name: "SEO 文章撰寫",               // 提示詞名稱
  category: "寫作",                   // 分類標籤
  content: "請幫我撰寫...[主題]...",  // 提示詞內容
  createdAt: "2025-10-22T...",       // 建立時間
  updatedAt: "2025-10-22T...",       // 更新時間
  usageCount: 0,                      // 使用次數
  lastUsedAt: "2025-10-22T..."       // 最後使用時間
}
```

### 儲存格式

**Chrome Storage：**
```javascript
{
  prompts: [
    { /* 提示詞物件 */ },
    { /* 提示詞物件 */ },
    ...
  ]
}
```

**匯出 JSON 格式：**
```javascript
{
  version: "1.0.0",
  exportedAt: "2025-10-22T...",
  prompts: [
    { /* 提示詞物件 */ },
    ...
  ]
}
```

## 🔄 使用流程

### 新增提示詞流程

```
1. 使用者點擊「+ 新增提示詞」
   ↓
2. 開啟編輯模態框
   ↓
3. 填寫名稱、分類、內容
   ↓
4. 使用快速插入按鈕新增變數 [變數名稱]
   ↓
5. 點擊「儲存」
   ↓
6. StorageManager.savePrompt() 儲存到 Chrome Storage
   ↓
7. 重新載入列表並顯示新提示詞
```

### 使用提示詞流程

```
1. 在 ChatGPT 頁面點擊擴充功能圖示
   ↓
2. 選擇想要使用的提示詞卡片
   ↓
3. StorageManager.extractVariables() 檢查是否有變數
   ↓
4a. 無變數：直接插入                4b. 有變數：顯示變數輸入框
   ↓                                     ↓
5a. 發送訊息到 content.js          5b. 使用者填寫變數
   ↓                                     ↓
6a. content.js 插入到輸入框        6b. StorageManager.replaceVariables()
                                         ↓
                                      7b. 發送訊息到 content.js
                                         ↓
                                      8b. content.js 插入到輸入框
   ↓
7. StorageManager.incrementUsageCount() 更新使用次數
   ↓
8. 關閉 popup 視窗
```

## 🎨 樣式設計

### 色彩系統

```css
--primary-color: #10a37f;      /* ChatGPT 品牌綠 */
--primary-hover: #0d8c6a;      /* 懸停狀態 */
--danger-color: #ef4444;       /* 刪除按鈕 */
--bg-primary: #ffffff;         /* 主背景 */
--bg-secondary: #f7f7f8;       /* 次背景 */
--text-primary: #202123;       /* 主文字 */
--text-secondary: #6e6e80;     /* 次文字 */
--border-color: #e5e5e5;       /* 邊框 */
```

### 響應式斷點

```css
@media (max-width: 768px) {
  /* 行動裝置樣式 */
}
```

## 🔐 權限說明

### manifest.json 權限

```json
"permissions": [
  "storage",     // 儲存提示詞資料
  "activeTab"    // 存取當前頁籤
]

"host_permissions": [
  "https://chat.openai.com/*",  // ChatGPT 官方
  "https://chatgpt.com/*"       // ChatGPT 新網域
]
```

## 🚀 啟動與測試

### 開發環境測試

1. **載入擴充功能**
   ```
   chrome://extensions/ → 開發人員模式 → 載入未封裝項目
   ```

2. **測試彈出視窗**
   - 點擊擴充功能圖示
   - 檢查 Console（右鍵 → 檢查）

3. **測試 Content Script**
   - 前往 ChatGPT
   - 開啟 DevTools (F12)
   - 檢查是否有浮動按鈕
   - 測試插入功能

4. **測試資料持久化**
   - 新增提示詞
   - 重新啟動瀏覽器
   - 檢查資料是否保留

### 除錯工具

- **Popup Console:** 右鍵點擊擴充功能圖示 → 檢查彈出式視窗
- **Background Console:** chrome://extensions/ → 服務工作程式
- **Content Script Console:** ChatGPT 頁面 F12

## 📊 效能考量

- ✅ 使用 debounce 優化搜尋
- ✅ 本地儲存，無網路延遲
- ✅ 事件委派減少記憶體使用
- ✅ 模態框使用 display 而非重新渲染

## 🔒 安全性

- ✅ 輸出時使用 HTML 轉義防止 XSS
- ✅ 僅在 ChatGPT 官方網域運作
- ✅ 不收集或傳送使用者資料
- ✅ 所有資料儲存在本地

## 🛣️ 未來擴展功能

### 計劃中的功能

- [ ] 提示詞資料夾分類
- [ ] 拖曳排序
- [ ] 提示詞模板市場
- [ ] 雲端同步
- [ ] 快捷鍵支援
- [ ] 支援更多 AI 平台（Claude、Gemini 等）
- [ ] 提示詞版本控制
- [ ] 協作與分享
- [ ] 統計分析儀表板

### 擴展建議

**支援其他 AI 平台：**
1. 修改 `manifest.json` 的 `host_permissions`
2. 調整 `content.js` 的選擇器陣列
3. 測試不同平台的輸入框

**新增快捷鍵：**
```json
"commands": {
  "open-prompt-manager": {
    "suggested_key": {
      "default": "Ctrl+Shift+P"
    },
    "description": "開啟提示詞管理器"
  }
}
```

## 📝 維護檢查清單

### 定期檢查

- [ ] ChatGPT 頁面結構是否改變
- [ ] Chrome API 是否有更新
- [ ] 使用者回饋和 Bug 報告
- [ ] 效能監控

### 更新流程

1. 修改程式碼
2. 更新版本號（manifest.json）
3. 測試所有功能
4. 更新 README.md
5. 建立 Git tag
6. 發布更新

## 📞 支援資源

- **文件：** README.md、INSTALLATION.md
- **圖示指南：** icons/README.md
- **Chrome 擴充功能文件：** [https://developer.chrome.com/docs/extensions/](https://developer.chrome.com/docs/extensions/)

---

**專案版本：** 1.0.0
**最後更新：** 2025-10-22
**授權：** MIT License
