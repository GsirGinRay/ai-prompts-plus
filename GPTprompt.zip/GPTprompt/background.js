/**
 * Background Service Worker
 * 處理背景任務和訊息轉發
 */

// 監聽擴充功能安裝
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('ChatGPT 提示詞管理工具已安裝');

    // 建立初始範例提示詞
    createSamplePrompts();
  } else if (details.reason === 'update') {
    console.log('ChatGPT 提示詞管理工具已更新');
  }
});

/**
 * 建立範例提示詞
 */
async function createSamplePrompts() {
  const samplePrompts = [
    {
      id: `prompt_${Date.now()}_sample1`,
      name: 'SEO 文章撰寫',
      category: '寫作',
      content: `請幫我撰寫一篇關於 [主題] 的 SEO 優化文章，目標關鍵字是 [關鍵字]，目標受眾是 [受眾]，文章長度約 [字數] 字，語氣要 [語氣風格]。

請確保文章包含：
1. 吸引人的標題
2. 清晰的段落結構
3. 適當的關鍵字密度
4. 實用的內容價值`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      usageCount: 0
    },
    {
      id: `prompt_${Date.now()}_sample2`,
      name: '程式碼審查',
      category: '程式設計',
      content: `請幫我審查以下 [程式語言] 程式碼，重點關注：

1. 程式碼品質和可讀性
2. 潛在的 bug 或錯誤
3. 效能優化建議
4. 安全性問題
5. 最佳實踐建議

程式碼：
[程式碼內容]`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      usageCount: 0
    },
    {
      id: `prompt_${Date.now()}_sample3`,
      name: '社群媒體貼文',
      category: '行銷',
      content: `請為 [平台] 撰寫一則關於 [主題] 的社群媒體貼文。

目標受眾：[受眾]
貼文語氣：[語氣]
字數限制：[字數]

請包含：
- 吸引人的開頭
- 清晰的價值主張
- 適當的標籤建議
- 行動呼籲（CTA）`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      usageCount: 0
    }
  ];

  try {
    await chrome.storage.local.set({ prompts: samplePrompts });
    console.log('範例提示詞已建立');
  } catch (error) {
    console.error('建立範例提示詞失敗:', error);
  }
}

/**
 * 監聽來自 content script 或 popup 的訊息
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openPopup') {
    chrome.action.openPopup();
    sendResponse({ success: true });
  }
  return true;
});

/**
 * 監聽快捷鍵命令
 */
chrome.commands.onCommand.addListener((command) => {
  if (command === 'open-prompt-manager') {
    chrome.action.openPopup();
  }
});
